Empty version: hardware only (chrome, blank faces, plates, windows, tiles).
No labels, units, numbers, ticks or scales are printed, so any slot can show any channel.
Needles are the Needle_*.png files in the folder above. Build steps: Part 7 of the Install Guide.
Slots.csv lists every slot's position and size, and what the printed version puts there.
